package com.cg.otb.dao;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.otb.dto.Show;
import com.cg.otb.exceptions.ShowException;
import com.cg.otb.util.DBUtil;

public class ShowDaoImpl implements ShowDao {

	public ShowDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	
	Connection conn = null;
	
	PreparedStatement pst = null;
	
	Statement st = null;
	
	ResultSet rs = null;

	@Override
	public List<Show> selectAllShows() throws ShowException {
		// TODO Auto-generated method stub
		
		List<Show> slist = new ArrayList<>();
		
		conn = DBUtil.getCon();
		
		String qry = "select * from ShowDetails";
		
		Show sh = null;
		
		try
		{
			st = conn.createStatement();
			
			rs = st.executeQuery(qry);
			
			while (rs.next()) {
				sh = new Show(rs.getString("ShowName"), rs.getString("Location")
						, rs.getDate("ShowDate"), rs.getInt("PriceTicket"), rs.getInt("AvSeats"));
				
				slist.add(sh);
			}
		}
		
		catch (Exception e)
		{
			throw new ShowException("Error while fetching Shows List");
		}
		
		return slist;
	}

	@Override
	public Show getShowDetails(String sname) throws ShowException {
		// TODO Auto-generated method stub
		
		String qry = "select ShowName, PriceTicket, AvSeats from ShowDetails"
				+ " where ShowName = ?";
		
		Show sh = null;
		
		conn = DBUtil.getCon();
		
		try {
			pst = conn.prepareStatement(qry);
			
			pst.setString(1, sname);
			
			rs = pst.executeQuery();
			
			while (rs.next())
			{
				sh = new Show(rs.getString("ShowName"), rs.getInt("PriceTicket"),
						 rs.getInt("AvSeats"));
			}
		}
		
		catch (SQLException se)
		{
			throw new ShowException("No Info Present For : " + sname);
		}
		
		return sh;
	}

	@Override
	public String updateShowDetails() throws ShowException {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}

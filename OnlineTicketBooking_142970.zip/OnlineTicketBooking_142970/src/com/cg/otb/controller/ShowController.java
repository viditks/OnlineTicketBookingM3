package com.cg.otb.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otb.dto.Show;
import com.cg.otb.exceptions.ShowException;
import com.cg.otb.service.ShowService;
import com.cg.otb.service.ShowServiceImpl;


@WebServlet(urlPatterns={"/home", "/showbook", "/booktickets"
		, "/index"})
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ShowController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String url = request.getServletPath();
		
		String targetUrl = "";
		
		HttpSession sess = null;
		
		ShowService showSer = new ShowServiceImpl();
		
		switch(url)
		{
			case "/home":
				
				try
				{
					List<Show> showList = showSer.selectAllShows();
					
					request.setAttribute("showList", showList);
					
					targetUrl = "Home.jsp";
				}
				
				catch (ShowException se)
				{
					request.setAttribute("error", se.getMessage());
					
					targetUrl = "Error.jsp";
				}
				break;
				
				case "/showbook":
					
					try
					{
						String showid = request.getParameter("showid");
						
						Show show = showSer.getShowDetails(showid);
						
						request.setAttribute("show", show);
						
						targetUrl = "BookNow.jsp";
					}
					
					catch (ShowException se)
					{
						request.setAttribute("error", se.getMessage());
						
						targetUrl = "Error.jsp";
					}
				
				break;
				
				case "/index":
					
					targetUrl = "index.jsp";
					
				break;
				
				case "/booktickets":
					
					Show sh = new Show();
					
					try
					{
						showSer.updateShowDetails();
						
						sess = request.getSession();
						
						sess.setAttribute("sh", sh);
						
						targetUrl = "Success.jsp";
					}
					
					catch (ShowException se)
					{
						request.setAttribute("error", se.getMessage());
						
						targetUrl = "Error.jsp";
					}
		}
	}

}

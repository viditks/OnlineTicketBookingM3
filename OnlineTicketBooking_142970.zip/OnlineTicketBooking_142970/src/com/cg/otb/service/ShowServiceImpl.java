package com.cg.otb.service;

import java.util.List;

import com.cg.otb.dao.ShowDao;
import com.cg.otb.dao.ShowDaoImpl;
import com.cg.otb.dto.Show;
import com.cg.otb.exceptions.ShowException;

public class ShowServiceImpl implements ShowService {

	ShowDao sdao = new ShowDaoImpl();
	
	public ShowServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Show> selectAllShows() throws ShowException {
		// TODO Auto-generated method stub
		return sdao.selectAllShows();
	}

	@Override
	public Show getShowDetails(String sname) throws ShowException {
		// TODO Auto-generated method stub
		return sdao.getShowDetails(sname);
	}

	@Override
	public String updateShowDetails() throws ShowException {
		// TODO Auto-generated method stub
		return sdao.updateShowDetails();
	}

}

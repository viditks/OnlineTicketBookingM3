package com.cg.otb.service;

import java.util.List;

import com.cg.otb.dto.Show;
import com.cg.otb.exceptions.ShowException;

public interface ShowService {
	
	public List<Show> selectAllShows() throws ShowException;
	
	public Show getShowDetails(String sname) throws ShowException;
	
	public String updateShowDetails() throws ShowException;
}

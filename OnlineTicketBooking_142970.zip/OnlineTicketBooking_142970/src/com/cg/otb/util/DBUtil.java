package com.cg.otb.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.otb.exceptions.ShowException;


public class DBUtil {

	public static Connection getCon() throws ShowException {
		
		Connection con = null;
		InitialContext context;
		
		try {
			//database configure from wildfly DSN online
			//now no need to use DriverManager to get Connection
			context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
		}
		catch (Exception e) {
			throw new ShowException(e.getMessage());
		}
		
		return con;
	}
	
	
}

package com.cg.otb.dto;

import java.sql.Date;

public class Show {

	public Show() {
		// TODO Auto-generated constructor stub
	}
	
	private String showId;
	private String showName;
	private String location;
	private Date showDate;
	private int availableSeats;
	private int priceTicket;
	
	public String getShowId() {
		return showId;
	}
	
	public void setShowId(String showId) {
		this.showId = showId;
	}
	
	public String getShowName() {
		return showName;
	}
	
	public void setShowName(String showName) {
		this.showName = showName;
	}
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public Date getShowDate() {
		return showDate;
	}
	
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	
	public int getAvailableSeats() {
		return availableSeats;
	}
	
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	
	public int getPriceTicket() {
		return priceTicket;
	}
	
	public void setPriceTicket(int priceTicket) {
		this.priceTicket = priceTicket;
	}

	public Show(String showId, String showName, String location, Date showDate,
			int availableSeats, int priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.availableSeats = availableSeats;
		this.priceTicket = priceTicket;
	}

	@Override
	public String toString() {
		return "Show [ Show ID = " + showId + ", Show Name = " + showName
				+ ", Location = " + location + ", Show Date = " + showDate
				+ ", Available Seats = " + availableSeats + ", Price Ticket = "
				+ priceTicket + " ]";
	}

	public Show(String showName, String location, Date showDate,
			int availableSeats, int priceTicket) {
		super();
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.availableSeats = availableSeats;
		this.priceTicket = priceTicket;
	}

	public Show(String showName, String location, Date showDate,
			int availableSeats) {
		super();
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.availableSeats = availableSeats;
	}

	public Show(String showName, int availableSeats, int priceTicket) {
		super();
		this.showName = showName;
		this.availableSeats = availableSeats;
		this.priceTicket = priceTicket;
	}
	
	
	
	

}

package com.cg.otbs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otbs.dto.showDetails;
import com.cg.otbs.exception.ShowException;
import com.cg.otbs.service.showService;
import com.cg.otbs.service.showServiceImpl;


@WebServlet(urlPatterns={"/listAllShows","/getShowDetails","/BookTicket"})
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	

	public ShowController() 
	{
		super();

	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);    //we are Calling doPost in doGet
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url = request.getServletPath() ;
		String targetUrl="" ;
		HttpSession session=null;
		showService showSer= new showServiceImpl();

		try
		{
			switch(url)
			{
			//First case will show all the details

			case "/listAllShows":
				try
				{
					
					List<showDetails> showList=showSer.getShowDetails();
					request.setAttribute("showList", showList);
					targetUrl="showDetails.jsp";
				}

				// if condition fails then we will be directed to error.jsp
				catch(ShowException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="error.jsp";
				}

				break;


				// this case will direct us to the bookNow.jsp page
			case "/getShowDetails":
				try
				{
					System.out.println("Showing Details in front of you ");
					String showid=request.getParameter("showid");
					showDetails show=showSer.getShowDetail(showid);
					request.setAttribute("show", show);
					targetUrl="bookNow.jsp";
				}

				// if condition fails then we will be directed to error.jsp
				catch(ShowException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="error.jsp";
				}

				break;	


			case "/BookTicket":
				try
				{
					String showName = request.getParameter("txtShowName");
					double price = Double.parseDouble(request.getParameter("txtPrice")) ;
					String customerName = request.getParameter("txtCustName");
					long mob =Long.parseLong(request.getParameter("txtMobNo"));
					int availSeats = Integer.parseInt(request.getParameter("txtSeatsAvail"));
					int noOfSeats = Integer.parseInt(request.getParameter("txtSeatsBook"));

					if(noOfSeats ==0 || noOfSeats <0)
					{
						throw new ShowException("Sorry!! Please enter valid seat number. ");
					}
					if(availSeats < noOfSeats)
					{
						throw new ShowException("Sorry !! Please enter valid number of seats. ");
					}
					else
					{
						int updatedSeats=availSeats - noOfSeats;
						request.setAttribute("showname", showName);
						request.setAttribute("cname", customerName);
						request.setAttribute("mobileNo", mob);
						request.setAttribute("noOfSeats", noOfSeats);
						double totalPrice= price * noOfSeats;
						request.setAttribute("totalPrice", totalPrice);
						showSer.updateShowDetails(updatedSeats, showName);
						targetUrl="success.jsp";

					}


				}
				
				// if condition fails then we will be directed to error.jsp
				catch(ShowException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="error.jsp";
				}

				break;
				
				//default case
			default:
				break;

			}


		}



		catch (Exception e) 
		{
			request.setAttribute("error", e.getMessage());
			targetUrl = "error.jsp" ;
		}



		//Request Dispatcher used for forwarding the request
		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);

	}

}

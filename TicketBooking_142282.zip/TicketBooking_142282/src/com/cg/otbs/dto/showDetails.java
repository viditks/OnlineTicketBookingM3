package com.cg.otbs.dto;

import java.sql.Date;

public class showDetails 
{
	private String showId ;
	private String showName ;
	private String location ;
	private Date showDate ;
	private int availableSeats ;
	private double price ;
	
	
	public String getShowId() 
	{
		return showId;
	}
	public void setShowId(String showId)
	{
		this.showId = showId;
	}
	public String getShowName()
	{
		return showName;
	}
	public void setShowName(String showName) 
	{
		this.showName = showName;
	}
	public String getLocation()
	{
		return location;
	}
	public void setLocation(String location)
	{
		this.location = location;
	}
	public Date getShowDate()
	{
		return showDate;
	}
	public void setShowDate(Date showDate)
	{
		this.showDate = showDate;
	}
	public int getAvailableSeats() 
	{
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats)
	{
		this.availableSeats = availableSeats;
	}
	public double getPrice()
	{
		return price;
	}
	public void setPrice(double price) 
	{
		this.price = price;
	}
	
	
	public showDetails()
	{
		super();
		
	}
	public showDetails(String showId, String showName, String location,
			Date showDate, int availableSeats, double price) 
	{
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.availableSeats = availableSeats;
		this.price = price;
	}
	
	@Override
	public String toString()
	{
		return "showDetails [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", availableSeats=" + availableSeats + ", price=" + price
				+ "]";
	}
	
	
	
	
	
}

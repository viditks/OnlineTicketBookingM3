package com.cg.otbs.dao;

import java.util.List;

import com.cg.otbs.dto.showDetails;
import com.cg.otbs.exception.ShowException;

public interface showDao 
{

	public List<showDetails> getShowDetails() throws ShowException ;
	public showDetails getShowDetail(String showid) throws ShowException ;
	public void updateShowDetails(int seats , String showname) throws ShowException ;
	
}

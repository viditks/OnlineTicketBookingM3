package com.cg.otbs.dao; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.otbs.dto.showDetails;
import com.cg.otbs.exception.ShowException;
import com.cg.otbs.util.DBUtil;

public class showDaoImpl implements showDao
{
	Connection con=null;
	Statement stm=null;
	PreparedStatement pstm=null;
	ResultSet res=null;
	
	
/***********************************to get the show details using list*******************************/	
	@Override
	public List<showDetails> getShowDetails() throws ShowException 
	{	
		List<showDetails> showDetailsList=new ArrayList<>();
		con=DBUtil.getCon();
		String query="Select * from showdetails";
		showDetails show=null;
		try
		{
			
			stm=con.createStatement();
			res=stm.executeQuery(query);
			while(res.next())
			{
				show=new showDetails(res.getString(1),res.getString(2),res.getString(3),res.getDate(4),res.getInt(5),res.getDouble(6));
				
				showDetailsList.add(show);
				
			}
		}
		catch(Exception e)
		{
			throw new ShowException("Error while fetching show details..");
			
		}
		
		return showDetailsList;
	}


/*******************************to get show details using showId as parameter**************************/	
	@Override
	public showDetails getShowDetail(String showid) throws ShowException 
	{
		showDetails show=null;
		String qry="Select * from showdetails where showid=?";
		try
		{
			con=DBUtil.getCon();
			pstm=con.prepareStatement(qry);
			pstm.setString(1, showid);
			res=pstm.executeQuery();
			res.next();
			show=new showDetails();
			
			show.setShowId(res.getString(1));
			show.setShowName(res.getString(2));
			show.setLocation(res.getString(3));
			show.setShowDate(res.getDate(4));
			show.setAvailableSeats(res.getInt(5));
			show.setPrice(res.getDouble(6));
			
			
		}
		catch(SQLException e)
		{
			throw new ShowException("Some error occured..Incorrect Show Id");
		}
		finally
		{
			try
			{
				res.close();
				stm.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new ShowException("Some error occure while fetching ");
			}
		}
		return show;
	}

/************************* to update show details using seats and showname as parameter***************/	
	@Override
	public void updateShowDetails(int seats, String showname)
			throws ShowException 
	{
		String updatequery="Update showdetails SET avseats = ? where showname = ?";
		try
		{
			con=DBUtil.getCon();
			pstm=con.prepareStatement(updatequery);
			pstm.setInt(1, seats);
			pstm.setString(2, showname);
			pstm.executeUpdate();
			
		}
		catch(SQLException e)
		{
			throw new ShowException("Some problem while updating records ");
		}
		
	}

}

package com.cg.otbs.service; 

import java.util.List;

import com.cg.otbs.dao.showDao;
import com.cg.otbs.dao.showDaoImpl;
import com.cg.otbs.dto.showDetails;
import com.cg.otbs.exception.ShowException;

public class showServiceImpl implements showService

{
	showDao shDao=new showDaoImpl();

/***********************************to get the show details using list*******************************/	

	@Override
	public List<showDetails> getShowDetails() throws ShowException 
	{
		
		return shDao.getShowDetails();
	}

/*******************************to get show details using showId as parameter**************************/	
	
	@Override
	public showDetails getShowDetail(String showid) throws ShowException
	{
		
		return shDao.getShowDetail(showid);
	}

/************************* to update show details using seats and showname as parameter***************/		
	@Override
	public void updateShowDetails(int seats, String showname)
			throws ShowException 
	{
		
		shDao.updateShowDetails(seats, showname);
	}

	
}
